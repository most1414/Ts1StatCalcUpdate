Few things to note:
- !!!! bonus stat points from ring/armor/necky aren't visually added to the main stats, they are in "Items Bonus Stats"
- items from the list are rares based of perfect stat rolls. Press custom to enter custom values
- the fact that you can go below 0 stat points is on purpose
- if you notice that something doesn't work properly or values in final stats are off by 2 or more vs what you see in game, dm me on discord vOSTRYv
- on vortex server chi has been nerfed to 18,5 for all factions